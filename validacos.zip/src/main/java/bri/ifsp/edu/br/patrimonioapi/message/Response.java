package bri.ifsp.edu.br.patrimonioapi.message;

public abstract class Response {

	public abstract String getMessage();
	
	public abstract boolean isError();
}
