package bri.ifsp.edu.br.patrimonioapi.config;

public class Constantes {

    public static final int INCLUIR = 1;
    public static final int ALTERAR = 2;
    public static final int EXCLUIR = 3;
    public static final int CONSULTAR = 4;
}
