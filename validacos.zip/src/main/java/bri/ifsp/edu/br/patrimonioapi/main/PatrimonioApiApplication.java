package bri.ifsp.edu.br.patrimonioapi.main;

import bri.ifsp.edu.br.patrimonioapi.view.patrimonio.TabelaPatrimonioView;

public class PatrimonioApiApplication {
	public static void main(String[] args) {

		TabelaPatrimonioView tabelaPatrimonioView = TabelaPatrimonioView.getInstancia();
		tabelaPatrimonioView.setVisible(true);
	}
}
